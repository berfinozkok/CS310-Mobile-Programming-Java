package edu.sabanciuniv.bozkokassignment2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

import java.util.List;

public class NewsDetails extends AppCompatActivity {
    Button checkComments;
    TextView toolbar;
    ImageView imgDetails;
    TextView txtTitle;
    TextView txtDate;
    TextView txtText;

    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            News nw = (News) msg.obj;
            toolbar.setText(nw.getCategoryName());
            txtTitle.setText(nw.getTitle());
            txtDate.setText(nw.getDate());
            txtText.setText(nw.getText());
            NewsRepository repo = new NewsRepository();
            repo.downloadImage(((NewsApp) getApplication()).srv, imgHandler, nw.getImage());
            return true;
        }
    });

    Handler imgHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            Bitmap img = (Bitmap) msg.obj;
            imgDetails.setImageBitmap(img);
            return true;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_details);
        int id = getIntent().getIntExtra("id", 1);
        checkComments = findViewById(R.id.checkComments);
        toolbar = findViewById(R.id.toolbarName);
        imgDetails = findViewById(R.id.imgDetails);
        txtTitle = findViewById(R.id.txtTitle);
        txtDate = findViewById(R.id.txtDate);
        txtText = findViewById(R.id.txtText);
        NewsRepository repo = new NewsRepository();
        repo.getNewsById(((NewsApp) getApplication()).srv, dataHandler, id);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        checkComments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(NewsDetails.this, CommentsActivity.class);
                i.putExtra("id", id);
                startActivity(i);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return true;
    }
}