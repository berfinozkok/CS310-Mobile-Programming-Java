package edu.sabanciuniv.bozkokassignment2;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;

public class NewsRepository{

    public void getAllNewsCategories(ExecutorService srv, Handler uiHandler) {
        srv.execute(() -> {
            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getallnewscategories");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder buffer = new StringBuilder();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }
                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(buffer.toString());
                JsonNode serviceMessageCode = root.get("serviceMessageCode");
                JsonNode serviceMessageText = root.get("serviceMessageText");
                JsonNode itemsNode = root.get("items");
                Log.d("i","All News Categories: "+itemsNode.toString());
                List<Categories> categories = new ArrayList<>();
                for (int i = 0; i < itemsNode.size(); i++) {
                    JsonNode current = itemsNode.get(i);
                    Categories category = new Categories(current.get("id").asInt(),
                            current.get("name").asText());
                    categories.add(category);
                }
                Message msg = new Message();
                msg.obj = categories;
                uiHandler.sendMessage(msg);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public void getAll(ExecutorService srv, Handler uiHandler) {
        srv.execute(() -> {
            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getall");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder buffer = new StringBuilder();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }
                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(buffer.toString());
                JsonNode serviceMessageCode = root.get("serviceMessageCode");
                JsonNode serviceMessageText = root.get("serviceMessageText");
                JsonNode itemsNode = root.get("items");
                Log.d("i","getAll: "+ itemsNode.toString());
                List<News> data = new ArrayList<>();
                for (int i = 0; i < itemsNode.size(); i++) {
                    JsonNode current = itemsNode.get(i);
                    News nw = new News(current.get("id").asInt(),
                            current.get("title").asText(),
                            current.get("text").asText(),
                            current.get("date").asText(),
                            current.get("image").asText(),
                            current.get("categoryName").asText());
                    data.add(nw);
                }
                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public void getNewsByCategoryId(ExecutorService srv, Handler uiHandler, int id){
        srv.execute(()->{
            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getbycategoryid/" + String.valueOf(id));
                HttpURLConnection conn =(HttpURLConnection)url.openConnection();
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder buffer = new StringBuilder();
                String line = "";
                while((line=reader.readLine())!=null){
                    buffer.append(line);
                }
                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(buffer.toString());
                JsonNode serviceMessageCode = root.get("serviceMessageCode");
                JsonNode serviceMessageText = root.get("serviceMessageText");
                JsonNode itemsNode = root.get("items");
                Log.d("i","News by Category id: "+ itemsNode.toString());
                List<News> data = new ArrayList<>();
                for (int i = 0; i < itemsNode.size(); i++) {
                    JsonNode current = itemsNode.get(i);
                    News nw = new News(current.get("id").asInt(),
                            current.get("title").asText(),
                            current.get("text").asText(),
                            current.get("date").asText(),
                            current.get("image").asText(),
                            current.get("categoryName").asText());
                    data.add(nw);
                }
                Message msg = new Message();
                msg.obj = data;
                uiHandler.sendMessage(msg);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public void getNewsById(ExecutorService srv, Handler uiHandler,int id){
        srv.execute(()->{
            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getnewsbyid/" + String.valueOf(id));
                HttpURLConnection conn =(HttpURLConnection)url.openConnection();
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder buffer = new StringBuilder();
                String line = "";
                while((line=reader.readLine())!=null){
                    buffer.append(line);
                }
                JSONObject jsonOb = new JSONObject(buffer.toString());
                Object serviceMessageCode = jsonOb.getInt("serviceMessageCode");
                Object serviceMessageText = jsonOb.getString("serviceMessageText");
                JSONArray arr=jsonOb.getJSONArray("items");
                Log.d("i","News by id: "+ arr.toString());
                News nw = new News();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject current = arr.getJSONObject(i);
                    nw.setId(current.getInt("id"));
                    nw.setTitle(current.getString("title"));
                    nw.setText(current.getString("text"));
                    nw.setDate( current.getString("date"));
                    nw.setImage( current.getString("image"));
                    nw.setCategoryName(current.getString("categoryName"));
                }
                Message msg = new Message();
                msg.obj = nw;
                uiHandler.sendMessage(msg);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        });
    }

    public void getCommentsById(ExecutorService srv, Handler uiHandler, int id) {
        srv.execute(() -> {
            try {
                URL url = new URL("http://10.3.0.14:8080/newsapp/getcommentsbynewsid/" + String.valueOf(id));
                HttpURLConnection conn =(HttpURLConnection)url.openConnection();
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder buffer = new StringBuilder();
                String line = "";
                while((line=reader.readLine())!=null){
                    buffer.append(line);
                }
                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(buffer.toString());
                JsonNode serviceMessageCode = root.get("serviceMessageCode");
                JsonNode serviceMessageText = root.get("serviceMessageText");
                JsonNode itemsNode = root.get("items");
                Log.d("i","Comments By Id"+ itemsNode.toString());
                List<Comments> comments = new ArrayList<>();
                for (int i = 0; i < itemsNode.size(); i++) {
                    JsonNode current = itemsNode.get(i);
                    Comments comm = new Comments(current.get("id").asInt(),
                            current.get("news_id").asInt(),
                            current.get("text").asText(),
                            current.get("name").asText());
                    comments.add(comm);
                }
                Message msg = new Message();
                msg.obj = comments;
                uiHandler.sendMessage(msg);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public void downloadImage(ExecutorService srv, Handler uiHandler, String path){
        srv.execute(()->{
            try {
                URL url = new URL(path);
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                Bitmap bitmap =  BitmapFactory.decodeStream(conn.getInputStream());
                Message msg = new Message();
                msg.obj = bitmap;
                uiHandler.sendMessage(msg);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

}