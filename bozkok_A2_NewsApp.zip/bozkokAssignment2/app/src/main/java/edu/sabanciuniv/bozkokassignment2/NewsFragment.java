package edu.sabanciuniv.bozkokassignment2;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import com.google.android.material.tabs.TabLayout;
import java.util.List;


public class NewsFragment extends Fragment {
    ProgressBar prg;
    RecyclerView recView;
    List<News> news;
    List<Categories> categories;
    TabLayout tabLayout;

    private static final String ARG_TAB_ID = "tab_id";
    public static NewsFragment newInstance(int tabId) {
        NewsFragment fragment = new NewsFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_TAB_ID, tabId);
        fragment.setArguments(args);
        return fragment;
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View frgNews = inflater.inflate(R.layout.fragment_news, container, false);
        recView = frgNews.findViewById(R.id.recyclerView);
        prg = frgNews.findViewById(R.id.progressBar);
        prg.setVisibility(View.VISIBLE);
        recView.setVisibility(View.INVISIBLE);
        if(getArguments() != null) {
            int tabId = getArguments().getInt(ARG_TAB_ID) +1 ;
            NewsRepository repo = new NewsRepository();
            repo.getNewsByCategoryId(((NewsApp) getActivity().getApplication()).srv, newsHandler, tabId);
        }
        return frgNews;
    }

    private final Handler newsHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<News> news = (List<News>)msg.obj;
            NewsAdapter adapter = new NewsAdapter(getContext(), news);
            recView.setAdapter(adapter);
            recView.setLayoutManager(new LinearLayoutManager(getContext()));
            prg.setVisibility(View.GONE);
            recView.setVisibility(View.VISIBLE);
            return true;
        }
    });
}

