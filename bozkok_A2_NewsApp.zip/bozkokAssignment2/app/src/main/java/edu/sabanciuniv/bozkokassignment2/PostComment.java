package edu.sabanciuniv.bozkokassignment2;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import org.json.JSONException;
import org.json.JSONObject;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

public class PostComment extends AppCompatActivity {

    private EditText nameAdd;
    private EditText commentAdd;
    private Button sendBtn;
    private ProgressBar progressBar;
    private TextView messageTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_comment);
        int id = getIntent().getIntExtra("id", 1);

        nameAdd = findViewById(R.id.nameAdd);
        commentAdd = findViewById(R.id.commentAdd);
        sendBtn = findViewById(R.id.sendBtn);
        progressBar = findViewById(R.id.progressBar);
        messageTextView = findViewById(R.id.messageTextView);

        sendBtn.setOnClickListener(view -> {
            progressBar.setVisibility(View.VISIBLE);
            String name = nameAdd.getText().toString();
            String comment = commentAdd.getText().toString();

            if (name.isEmpty() || comment.isEmpty()) {
                progressBar.setVisibility(View.GONE);
                messageTextView.setText("Name and comment must not be empty.");
                messageTextView.setVisibility(View.VISIBLE);
            } else {
                new Thread(()->{
                    OkHttpClient client = new OkHttpClient();
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("name", name);
                        jsonObject.put("text", comment);
                        jsonObject.put("news_id", String.valueOf(id));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    RequestBody requestBody = RequestBody.create(MediaType.parse("application/json"), jsonObject.toString());
                    Request request = new Request.Builder()
                            .url("http://10.3.0.14:8080/newsapp/savecomment")
                            .addHeader("Content-Type", "application/json")
                            .post(requestBody)
                            .build();
                    try (Response response = client.newCall(request).execute()) {
                        if (response.code() == 200) {
                            runOnUiThread(() -> {
                                progressBar.setVisibility(View.GONE);
                                messageTextView.setText("Successfully submitted");
                                messageTextView.setVisibility(View.VISIBLE);
                                Intent i = new Intent(PostComment.this, CommentsActivity.class);
                                i.putExtra("id", id);
                                startActivity(i);

                            });
                        } else {
                            runOnUiThread(() -> {
                                progressBar.setVisibility(View.GONE);
                                messageTextView.setText("Not submitted");
                                messageTextView.setVisibility(View.VISIBLE);
                            });
                        }
                    } catch (IOException e) {
                    }
                }).start();
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return true;
    }

}