package edu.sabanciuniv.bozkokassignment2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.List;

public class CommentsActivity extends AppCompatActivity {
    ProgressBar progressBar;
    Button commentBtn;
    RecyclerView recComment;

    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<Comments> comments = (List<Comments>) msg.obj;
            CommentsAdapter adapter = new CommentsAdapter(CommentsActivity.this, comments);
            recComment.setAdapter(adapter);
            progressBar.setVisibility(View.GONE);
            return true;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);
        int id = getIntent().getIntExtra("id", 1);
        progressBar = findViewById(R.id.prgBar);
        progressBar.setVisibility(View.VISIBLE);
        commentBtn = findViewById(R.id.commentBtn);
        recComment = findViewById(R.id.recComment);
        recComment.setLayoutManager(new LinearLayoutManager(this));

        NewsRepository repo = new NewsRepository();
        progressBar.setVisibility(View.VISIBLE);
        repo.getCommentsById(((NewsApp) getApplication()).srv, dataHandler, id);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        commentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = getIntent().getIntExtra("id", 1);
                Intent intent = new Intent(CommentsActivity.this, PostComment.class);
                intent.putExtra("id", id);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return true;
    }
}