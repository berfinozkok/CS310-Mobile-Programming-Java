package edu.sabanciuniv.bozkokassignment2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.concurrent.ExecutorService;

public class CommentsAdapter extends RecyclerView.Adapter<CommentsAdapter.CommentsViewHolder>{
    private Context ctx;
    private List<Comments> comments;

    public CommentsAdapter(Context ctx, List<Comments> comments){
        this.ctx = ctx;
        this.comments = comments;
    }

    @NonNull
    @Override
    public CommentsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View root= LayoutInflater.from(ctx).inflate(R.layout.comments_row_layout,parent,false);
        CommentsViewHolder holder = new CommentsViewHolder(root);
        holder.setIsRecyclable(false);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull CommentsViewHolder holder, int position) {
        holder.textCName.setText(comments.get(holder.getAdapterPosition()).getName());
        holder.textComment.setText(comments.get(holder.getAdapterPosition()).getText());
        holder.commentImg.setImageResource(R.drawable.anonymous_avatar);
        NewsApp app = (NewsApp) ((AppCompatActivity)ctx).getApplication();
        holder.crow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ctx,Comments.class);
                i.putExtra("id",comments.get(holder.getAdapterPosition()).getId());
                ctx.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return comments.size();
    }

    class CommentsViewHolder extends RecyclerView.ViewHolder{
        ImageView commentImg;
        TextView textCName;
        TextView textComment;
        ConstraintLayout crow;

        public CommentsViewHolder(@NonNull View itemView) {
            super(itemView);
            textCName = itemView.findViewById(R.id.textCName);
            textComment = itemView.findViewById(R.id.textComment);
            commentImg = itemView.findViewById(R.id.commentImg);
            crow = itemView.findViewById(R.id.crow_list);
        }
    }
}
