package edu.sabanciuniv.bozkokassignment2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import java.util.Collections;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ProgressBar;

import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;

import java.util.List;

public class MainActivity extends AppCompatActivity{
    TabLayout tabView;
    ViewPager2 viewPager2;
    ProgressBar prg;
    RecyclerView recView;
    private List<News> news;

    Handler dataHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            List<Categories> data = (List<Categories>)msg.obj;
            Collections.sort(data, (c1, c2) -> c1.getId() - c2.getId());
            for (Categories category : data) {
                TabLayout.Tab tab = tabView.newTab();
                tab.setText(category.getName());
                tabView.addTab(tab);
            }
            tabView.setVisibility(View.VISIBLE);
            return true;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_baseline_home_24);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tabView = findViewById(R.id.tabLayoutList);
        viewPager2 = findViewById(R.id.viewpager2);
        tabView.setVisibility(View.INVISIBLE);
        NewsRepository repo = new NewsRepository();
        repo.getAllNewsCategories(((NewsApp) getApplication()).srv, dataHandler);

        tabView.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem((tab.getPosition()));
                int tabId = tab.getPosition();
                NewsFragment newsFragment = NewsFragment.newInstance(tabId);
                FragmentTransaction trans = getSupportFragmentManager().beginTransaction();
                trans.replace(R.id.frgContainer, newsFragment);
                trans.addToBackStack(null);
                trans.commit();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback(){
            @Override
            public void onPageSelected(int position){
                super.onPageSelected(position);
                tabView.getTabAt(position).select();
            }
        });
    }
}